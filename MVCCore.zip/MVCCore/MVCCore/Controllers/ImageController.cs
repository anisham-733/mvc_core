﻿using Microsoft.AspNetCore.Mvc;

namespace MVCCore.Controllers
{
    public class ImageController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
