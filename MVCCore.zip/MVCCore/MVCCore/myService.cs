﻿using System;

namespace MVCCore
{
    public interface IDemo
    {
        void printName(string name);
    }
    public class myService : IDemo
    {
        public void printName(string name)
        {
            Console.WriteLine("Hello " + name);
        }
    }
}
