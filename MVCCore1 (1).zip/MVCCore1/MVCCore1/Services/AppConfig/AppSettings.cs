﻿namespace MVCCore1.Services.AppConfig
{
    public class AppSettings
    {
        public static string sections = "ConnectionStrings";
        public string AccessKey { get; set; }
        public string Conn { get; set; }
        public string ConnectionStrings { get; set; }
    }
}
